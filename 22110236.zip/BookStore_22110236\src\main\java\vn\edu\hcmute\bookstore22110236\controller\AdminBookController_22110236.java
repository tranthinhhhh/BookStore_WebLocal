package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.User_22110236;
import vn.edu.hcmute.bookstore22110236.service.BookService_22110236;
import vn.edu.hcmute.bookstore22110236.service.IBookService_22110236;
import vn.edu.hcmute.bookstore22110236.service.ServiceException_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@WebServlet(urlPatterns = {"/admin/books", "/admin/books/*"})
public class AdminBookController_22110236 extends HttpServlet {
    private final IBookService_22110236 bookService = new BookService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!requireAdmin(request, response)) return;
        String action = request.getPathInfo();
        if (action == null || action.equals("/") || action.isBlank()) {
            showList(request, response);
        } else if (action.equals("/new")) {
            showForm(request, response, new Book_22110236());
        } else if (action.equals("/edit")) {
            int id = ControllerUtil_22110236.parseInt(request.getParameter("id"), 0);
            Optional<Book_22110236> book = bookService.getById(id);
            if (book.isEmpty()) response.sendError(HttpServletResponse.SC_NOT_FOUND);
            else showForm(request, response, book.get());
        } else {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (!requireAdmin(request, response)) return;
        String action = request.getPathInfo();
        if ("/save".equals(action)) save(request, response);
        else if ("/delete".equals(action)) delete(request, response);
        else response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
    }

    private void showList(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int page = ControllerUtil_22110236.parseInt(request.getParameter("page"), 1);
        request.setAttribute("bookPage", bookService.getBooksForAdmin(page));
        request.getRequestDispatcher("/WEB-INF/views/admin/books.jsp").forward(request, response);
    }

    private void showForm(HttpServletRequest request, HttpServletResponse response, Book_22110236 book)
            throws ServletException, IOException {
        request.setAttribute("book", book);
        request.setAttribute("authors", bookService.getAuthors());
        Set<Integer> selected = new HashSet<>();
        book.getAuthors().forEach(author -> selected.add(author.getAuthorId()));
        request.setAttribute("selectedAuthorIds", selected);
        request.getRequestDispatcher("/WEB-INF/views/admin/book-form.jsp").forward(request, response);
    }

    private void save(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Book_22110236 book = new Book_22110236();
        try {
            book.setBookId(ControllerUtil_22110236.parseInt(request.getParameter("bookId"), 0));
            book.setIsbn(value(request, "isbn"));
            book.setTitle(value(request, "title"));
            book.setPublisher(value(request, "publisher"));
            book.setPrice(new BigDecimal(value(request, "price")));
            book.setDescription(value(request, "description"));
            String date = value(request, "publishDate");
            book.setPublishDate(date.isBlank() ? null : LocalDate.parse(date));
            book.setCoverImage(value(request, "coverImage"));
            book.setQuantity(Integer.parseInt(value(request, "quantity")));
            List<Integer> authorIds = parseAuthorIds(request.getParameterValues("authorIds"));
            bookService.save(book, authorIds);
            response.sendRedirect(request.getContextPath() + "/admin/books?status=saved");
        } catch (NumberFormatException | DateTimeParseException | ServiceException_22110236 exception) {
            request.setAttribute("error", exception instanceof ServiceException_22110236
                    ? exception.getMessage() : "Giá, số lượng hoặc ngày xuất bản không hợp lệ.");
            request.setAttribute("book", book);
            request.setAttribute("authors", bookService.getAuthors());
            request.setAttribute("selectedAuthorIds", new HashSet<>(
                    parseAuthorIds(request.getParameterValues("authorIds"))));
            request.getRequestDispatcher("/WEB-INF/views/admin/book-form.jsp").forward(request, response);
        }
    }

    private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            int id = ControllerUtil_22110236.parseInt(request.getParameter("id"), 0);
            bookService.delete(id);
            response.sendRedirect(request.getContextPath() + "/admin/books?status=deleted");
        } catch (RuntimeException exception) {
            response.sendRedirect(request.getContextPath() + "/admin/books?status=deleteError");
        }
    }

    private List<Integer> parseAuthorIds(String[] values) {
        List<Integer> ids = new ArrayList<>();
        if (values != null) {
            for (String value : values) {
                int id = ControllerUtil_22110236.parseInt(value, 0);
                if (id > 0 && !ids.contains(id)) ids.add(id);
            }
        }
        return ids;
    }

    private String value(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        return value == null ? "" : value.trim();
    }

    private boolean requireAdmin(HttpServletRequest request, HttpServletResponse response) throws IOException {
        Object value = request.getSession(false) == null ? null
                : request.getSession(false).getAttribute("currentUser");
        if (!(value instanceof User_22110236 user) || !user.isAdmin()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return false;
        }
        return true;
    }
}
