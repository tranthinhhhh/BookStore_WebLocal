package vn.edu.hcmute.bookstore22110236.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;

public final class OtpUtil_22110236 {
    private static final SecureRandom RANDOM = new SecureRandom();

    private OtpUtil_22110236() {
    }

    public static String generate() {
        return "%06d".formatted(RANDOM.nextInt(1_000_000));
    }

    public static String digest(String otp) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(otp.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException(exception);
        }
    }

    public static boolean matches(String otp, String expectedDigest) {
        byte[] actual = digest(otp == null ? "" : otp).getBytes(StandardCharsets.UTF_8);
        byte[] expected = expectedDigest.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(actual, expected);
    }
}
