package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.config.DatabaseConnection_22110236;
import vn.edu.hcmute.bookstore22110236.model.User_22110236;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Optional;

public class UserRepository_22110236 implements IUserRepository_22110236 {
    @Override
    public Optional<User_22110236> findByEmail(String email) {
        String sql = "SELECT id, email, fullname, phone, passwd, signup_date, last_login, is_admin "
                + "FROM users WHERE LOWER(email) = LOWER(?)";
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, email);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? Optional.of(mapUser(resultSet)) : Optional.empty();
            }
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể truy vấn người dùng.", exception);
        }
    }

    @Override
    public User_22110236 create(User_22110236 user) {
        String sql = "INSERT INTO users(email, fullname, phone, passwd, signup_date, is_admin) "
                + "VALUES (?, ?, ?, ?, SYSDATETIME(), 0)";
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, user.getEmail());
            statement.setString(2, user.getFullName());
            statement.setString(3, user.getPhone());
            statement.setString(4, user.getPasswordHash());
            statement.executeUpdate();
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) user.setId(keys.getInt(1));
            }
            return user;
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tạo tài khoản; email có thể đã tồn tại.", exception);
        }
    }

    @Override
    public void updateLastLogin(int userId) {
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE users SET last_login = SYSDATETIME() WHERE id = ?")) {
            statement.setInt(1, userId);
            statement.executeUpdate();
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể cập nhật lần đăng nhập.", exception);
        }
    }

    private User_22110236 mapUser(ResultSet resultSet) throws SQLException {
        User_22110236 user = new User_22110236();
        user.setId(resultSet.getInt("id"));
        user.setEmail(resultSet.getString("email"));
        user.setFullName(resultSet.getString("fullname"));
        user.setPhone(resultSet.getString("phone"));
        user.setPasswordHash(resultSet.getString("passwd"));
        Timestamp signup = resultSet.getTimestamp("signup_date");
        Timestamp login = resultSet.getTimestamp("last_login");
        if (signup != null) user.setSignupDate(signup.toLocalDateTime());
        if (login != null) user.setLastLogin(login.toLocalDateTime());
        user.setAdmin(resultSet.getBoolean("is_admin"));
        return user;
    }
}
