<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Quản lý sách</title></head>
<body>
<div class="admin-toolbar">
    <div><h1>Quản lý sách</h1><p class="lead">CRUD Books có phân trang 5 sách mỗi trang.</p></div>
    <a class="button" href="${pageContext.request.contextPath}/admin/books/new">Thêm sách</a>
</div>
<c:if test="${param.status == 'saved'}"><div class="alert success">Đã lưu thông tin sách.</div></c:if>
<c:if test="${param.status == 'deleted'}"><div class="alert success">Đã xóa sách và dữ liệu liên quan.</div></c:if>
<c:if test="${param.status == 'deleteError'}"><div class="alert error">Không thể xóa sách do dữ liệu liên quan hoặc lỗi cơ sở dữ liệu.</div></c:if>
<div class="table-wrap">
    <table>
        <thead><tr><th>ID</th><th>ISBN</th><th>Tiêu đề</th><th>Tác giả</th><th>Số lượng</th><th>Review</th><th>Thao tác</th></tr></thead>
        <tbody>
        <c:forEach var="book" items="${bookPage.items}">
            <tr>
                <td><c:out value="${book.bookId}"/></td>
                <td><c:out value="${book.isbn}"/></td>
                <td><c:out value="${book.title}"/></td>
                <td><c:out value="${book.authorsText}"/></td>
                <td><c:out value="${book.quantity}"/></td>
                <td><c:out value="${book.reviewCount}"/></td>
                <td class="actions">
                    <a class="button secondary" href="${pageContext.request.contextPath}/admin/books/edit?id=${book.bookId}">Sửa</a>
                    <form method="post" action="${pageContext.request.contextPath}/admin/books/delete" onsubmit="return confirm('Xóa sách này?');">
                        <input type="hidden" name="id" value="${book.bookId}">
                        <button class="button danger" type="submit">Xóa</button>
                    </form>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty bookPage.items}"><tr><td colspan="7" class="empty-state">Chưa có sách.</td></tr></c:if>
        </tbody>
    </table>
</div>
<nav class="pagination" aria-label="Phân trang quản trị">
    <c:choose><c:when test="${bookPage.hasPrevious}"><a href="?page=${bookPage.page - 1}">Trang trước</a></c:when><c:otherwise><span class="disabled">Trang trước</span></c:otherwise></c:choose>
    <c:forEach begin="1" end="${bookPage.totalPages}" var="number"><a class="${number == bookPage.page ? 'active' : ''}" href="?page=${number}">${number}</a></c:forEach>
    <c:choose><c:when test="${bookPage.hasNext}"><a href="?page=${bookPage.page + 1}">Trang sau</a></c:when><c:otherwise><span class="disabled">Trang sau</span></c:otherwise></c:choose>
</nav>
</body>
</html>
