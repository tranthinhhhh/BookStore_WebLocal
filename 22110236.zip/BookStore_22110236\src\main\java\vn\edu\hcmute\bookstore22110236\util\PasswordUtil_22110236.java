package vn.edu.hcmute.bookstore22110236.util;

import org.mindrot.jbcrypt.BCrypt;

public final class PasswordUtil_22110236 {
    private PasswordUtil_22110236() {
    }

    public static String hash(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }

    public static boolean verify(String plainPassword, String passwordHash) {
        try {
            return passwordHash != null && BCrypt.checkpw(plainPassword, passwordHash);
        } catch (IllegalArgumentException exception) {
            return false;
        }
    }
}
