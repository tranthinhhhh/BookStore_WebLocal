package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.Rating_22110236;
import vn.edu.hcmute.bookstore22110236.repository.IRatingRepository_22110236;
import vn.edu.hcmute.bookstore22110236.repository.RatingRepository_22110236;

import java.util.List;

public class RatingService_22110236 implements IRatingService_22110236 {
    private final IRatingRepository_22110236 repository;

    public RatingService_22110236() {
        this(new RatingRepository_22110236());
    }

    public RatingService_22110236(IRatingRepository_22110236 repository) {
        this.repository = repository;
    }

    @Override
    public List<Rating_22110236> getByBookId(int bookId) {
        return repository.findByBookId(bookId);
    }

    @Override
    public void save(int userId, int bookId, int stars, String reviewText) {
        if (stars < 1 || stars > 5) throw new ServiceException_22110236("Số sao phải từ 1 đến 5.");
        String text = reviewText == null ? "" : reviewText.trim();
        if (text.length() < 3 || text.length() > 2000) {
            throw new ServiceException_22110236("Nội dung đánh giá phải có từ 3 đến 2000 ký tự.");
        }
        Rating_22110236 rating = new Rating_22110236();
        rating.setUserId(userId);
        rating.setBookId(bookId);
        rating.setRating(stars);
        rating.setReviewText(text);
        repository.saveOrUpdate(rating);
    }
}
