package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.PendingRegistration_22110236;
import vn.edu.hcmute.bookstore22110236.model.User_22110236;
import vn.edu.hcmute.bookstore22110236.repository.IUserRepository_22110236;
import vn.edu.hcmute.bookstore22110236.repository.UserRepository_22110236;
import vn.edu.hcmute.bookstore22110236.util.PasswordUtil_22110236;

import java.util.Locale;
import java.util.Optional;

public class UserService_22110236 implements IUserService_22110236 {
    private final IUserRepository_22110236 repository;

    public UserService_22110236() {
        this(new UserRepository_22110236());
    }

    public UserService_22110236(IUserRepository_22110236 repository) {
        this.repository = repository;
    }

    @Override
    public boolean emailExists(String email) {
        return repository.findByEmail(normalizeEmail(email)).isPresent();
    }

    @Override
    public Optional<User_22110236> authenticate(String email, String password) {
        Optional<User_22110236> user = repository.findByEmail(normalizeEmail(email));
        if (user.isEmpty() || !PasswordUtil_22110236.verify(password, user.get().getPasswordHash())) {
            return Optional.empty();
        }
        repository.updateLastLogin(user.get().getId());
        return user;
    }

    @Override
    public User_22110236 activate(PendingRegistration_22110236 pending) {
        if (emailExists(pending.getEmail())) throw new ServiceException_22110236("Email đã được đăng ký.");
        User_22110236 user = new User_22110236();
        user.setEmail(normalizeEmail(pending.getEmail()));
        user.setFullName(pending.getFullName().trim());
        user.setPhone(pending.getPhone());
        user.setPasswordHash(pending.getPasswordHash());
        return repository.create(user);
    }

    private String normalizeEmail(String email) {
        return email == null ? "" : email.trim().toLowerCase(Locale.ROOT);
    }
}
