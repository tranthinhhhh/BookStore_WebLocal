package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.model.User_22110236;

import java.util.Optional;

public interface IUserRepository_22110236 {
    Optional<User_22110236> findByEmail(String email);
    User_22110236 create(User_22110236 user);
    void updateLastLogin(int userId);
}
