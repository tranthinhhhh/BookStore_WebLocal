package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.PendingRegistration_22110236;
import vn.edu.hcmute.bookstore22110236.model.User_22110236;

import java.util.Optional;

public interface IUserService_22110236 {
    boolean emailExists(String email);
    Optional<User_22110236> authenticate(String email, String password);
    User_22110236 activate(PendingRegistration_22110236 pendingRegistration);
}
