<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title><c:out value="${book.title}"/></title></head>
<body>
<c:if test="${param.review == 'success'}"><div class="alert success">Đã lưu đánh giá của bạn.</div></c:if>
<c:if test="${not empty param.error}"><div class="alert error"><c:out value="${param.error}"/></div></c:if>
<section class="panel detail-grid">
    <img class="detail-cover" src="${pageContext.request.contextPath}${book.coverImage}" alt="Bìa sách ${book.title}">
    <div>
        <h1><c:out value="${book.title}"/></h1>
        <p class="price"><c:out value="${book.price}"/> VNĐ</p>
        <dl class="book-meta">
            <dt>Mã ISBN</dt><dd><c:out value="${book.isbn}"/></dd>
            <dt>Tác giả</dt><dd><c:out value="${book.authorsText}"/></dd>
            <dt>Publisher</dt><dd><c:out value="${book.publisher}"/></dd>
            <dt>Publish date</dt><dd><c:out value="${book.publishDate}"/></dd>
            <dt>Quantity</dt><dd><c:out value="${book.quantity}"/></dd>
            <dt>Reviews</dt><dd><c:out value="${book.reviewCount}"/></dd>
        </dl>
        <p><c:out value="${book.description}"/></p>
    </div>
</section>

<section class="panel reviews">
    <h2>Reviews (<c:out value="${book.reviewCount}"/>)</h2>
    <c:choose>
        <c:when test="${empty reviews}"><p class="empty-state">Chưa có đánh giá nào.</p></c:when>
        <c:otherwise>
            <c:forEach var="review" items="${reviews}">
                <article class="review">
                    <strong><c:out value="${review.userName}"/></strong>
                    <div class="stars" aria-label="${review.rating} trên 5 sao">
                        <c:forEach begin="1" end="${review.rating}">★</c:forEach>
                    </div>
                    <p><c:out value="${review.reviewText}"/></p>
                </article>
            </c:forEach>
        </c:otherwise>
    </c:choose>

    <c:choose>
        <c:when test="${not empty sessionScope.currentUser}">
            <form class="inline-form" method="post" action="${pageContext.request.contextPath}/reviews/save">
                <input type="hidden" name="bookId" value="${book.bookId}">
                <div class="form-group">
                    <label for="rating">Số sao</label>
                    <select id="rating" name="rating" required>
                        <option value="5">5 - Rất tốt</option><option value="4">4 - Tốt</option>
                        <option value="3">3 - Khá</option><option value="2">2 - Trung bình</option>
                        <option value="1">1 - Chưa tốt</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="reviewText">Nội dung đánh giá</label>
                    <textarea id="reviewText" name="reviewText" maxlength="2000" minlength="3" required></textarea>
                </div>
                <button class="button" type="submit">Submit</button>
            </form>
        </c:when>
        <c:otherwise>
            <p><a class="button" href="${pageContext.request.contextPath}/login">Đăng nhập để thêm review</a></p>
        </c:otherwise>
    </c:choose>
</section>
</body>
</html>
