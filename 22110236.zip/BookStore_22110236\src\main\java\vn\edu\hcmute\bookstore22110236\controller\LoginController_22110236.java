package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.User_22110236;
import vn.edu.hcmute.bookstore22110236.service.IUserService_22110236;
import vn.edu.hcmute.bookstore22110236.service.UserService_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Optional;

@WebServlet("/login")
public class LoginController_22110236 extends HttpServlet {
    private final IUserService_22110236 userService = new UserService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/auth/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        Optional<User_22110236> authenticated = userService.authenticate(email, password);
        if (authenticated.isEmpty()) {
            request.setAttribute("error", "Email hoặc mật khẩu không đúng.");
            request.setAttribute("email", email);
            doGet(request, response);
            return;
        }
        HttpSession session = request.getSession(true);
        request.changeSessionId();
        session.setAttribute("currentUser", authenticated.get());
        session.setMaxInactiveInterval(30 * 60);
        String destination = authenticated.get().isAdmin() ? "/admin/books" : "/home";
        response.sendRedirect(request.getContextPath() + destination);
    }
}
