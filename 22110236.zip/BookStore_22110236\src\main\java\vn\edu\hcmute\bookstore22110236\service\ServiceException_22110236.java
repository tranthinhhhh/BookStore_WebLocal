package vn.edu.hcmute.bookstore22110236.service;

public class ServiceException_22110236 extends RuntimeException {
    public ServiceException_22110236(String message) {
        super(message);
    }

    public ServiceException_22110236(String message, Throwable cause) {
        super(message, cause);
    }
}
