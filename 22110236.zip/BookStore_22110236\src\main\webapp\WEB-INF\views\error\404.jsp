<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><head><title>Không tìm thấy</title></head><body><section class="panel empty-state"><h1>404</h1><p>Không tìm thấy trang hoặc cuốn sách được yêu cầu.</p><a class="button" href="${pageContext.request.contextPath}/home">Về trang chủ</a></section></body></html>
