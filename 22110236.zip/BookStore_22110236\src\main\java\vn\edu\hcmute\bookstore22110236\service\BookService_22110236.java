package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.Author_22110236;
import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.PageResult_22110236;
import vn.edu.hcmute.bookstore22110236.repository.BookRepository_22110236;
import vn.edu.hcmute.bookstore22110236.repository.IBookRepository_22110236;
import vn.edu.hcmute.bookstore22110236.util.ValidationUtil_22110236;

import java.util.List;
import java.util.Optional;

public class BookService_22110236 implements IBookService_22110236 {
    public static final int HOME_PAGE_SIZE = 3;
    public static final int ADMIN_PAGE_SIZE = 5;
    private final IBookRepository_22110236 repository;

    public BookService_22110236() {
        this(new BookRepository_22110236());
    }

    public BookService_22110236(IBookRepository_22110236 repository) {
        this.repository = repository;
    }

    @Override
    public List<Author_22110236> getAuthors() {
        return repository.findAllAuthors();
    }

    @Override
    public PageResult_22110236<Book_22110236> getBooksByAuthor(int authorId, int page) {
        return repository.findByAuthor(authorId, Math.max(page, 1), HOME_PAGE_SIZE);
    }

    @Override
    public PageResult_22110236<Book_22110236> getBooksForAdmin(int page) {
        return repository.findAll(Math.max(page, 1), ADMIN_PAGE_SIZE);
    }

    @Override
    public Optional<Book_22110236> getById(int bookId) {
        return repository.findById(bookId);
    }

    @Override
    public int save(Book_22110236 book, List<Integer> authorIds) {
        List<String> errors = ValidationUtil_22110236.validateBook(
                book.getIsbn(), book.getTitle(), book.getPublisher(), book.getPrice(), book.getQuantity());
        if (authorIds == null || authorIds.isEmpty()) errors.add("Phải chọn ít nhất một tác giả.");
        if (repository.isbnExists(book.getIsbn(), book.getBookId())) errors.add("ISBN đã tồn tại.");
        if (!errors.isEmpty()) throw new ServiceException_22110236(String.join(" ", errors));
        if (book.getCoverImage() == null || book.getCoverImage().isBlank()) {
            book.setCoverImage("/assets/images/book-default.svg");
        }
        if (book.getBookId() == 0) return repository.create(book, authorIds);
        repository.update(book, authorIds);
        return book.getBookId();
    }

    @Override
    public void delete(int bookId) {
        if (bookId <= 0) throw new ServiceException_22110236("Mã sách không hợp lệ.");
        repository.delete(bookId);
    }
}
