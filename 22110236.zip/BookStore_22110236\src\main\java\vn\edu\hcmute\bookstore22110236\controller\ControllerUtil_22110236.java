package vn.edu.hcmute.bookstore22110236.controller;

public final class ControllerUtil_22110236 {
    private ControllerUtil_22110236() {
    }

    public static int parseInt(String value, int defaultValue) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException exception) {
            return defaultValue;
        }
    }
}
