package vn.edu.hcmute.bookstore22110236.filter;

import vn.edu.hcmute.bookstore22110236.model.User_22110236;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AdminAuthorizationFilter_22110236 implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        Object sessionUser = httpRequest.getSession(false) == null ? null
                : httpRequest.getSession(false).getAttribute("currentUser");
        if (!(sessionUser instanceof User_22110236 user) || !user.isAdmin()) {
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login?error=forbidden");
            return;
        }
        chain.doFilter(request, response);
    }
}
