:setvar DatabaseName "BookStore_22110236"
:setvar AppLogin "bookstore_app"
-- Truyền AppLoginPassword khi chạy sqlcmd, ví dụ: -v AppLoginPassword="mat-khau-cuc-bo"

IF DB_ID(N'$(DatabaseName)') IS NULL
BEGIN
    EXEC(N'CREATE DATABASE [' + '$(DatabaseName)' + N']');
END
GO

USE [$(DatabaseName)];
GO
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

IF OBJECT_ID(N'dbo.books', N'U') IS NULL
BEGIN
CREATE TABLE dbo.books (
    bookid INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_books PRIMARY KEY,
    isbn VARCHAR(20) NULL,
    title NVARCHAR(200) NULL,
    publisher NVARCHAR(100) NULL,
    price DECIMAL(6,2) NULL,
    description NVARCHAR(MAX) NULL,
    publish_date DATE NULL,
    cover_image VARCHAR(255) NULL,
    quantity INT NULL CONSTRAINT CK_books_quantity CHECK (quantity >= 0)
);
END
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_books_isbn' AND object_id = OBJECT_ID(N'dbo.books'))
    CREATE UNIQUE INDEX UX_books_isbn ON dbo.books(isbn) WHERE isbn IS NOT NULL;

IF OBJECT_ID(N'dbo.users', N'U') IS NULL
BEGIN
CREATE TABLE dbo.users (
    id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_users PRIMARY KEY,
    email VARCHAR(254) NOT NULL,
    fullname NVARCHAR(100) NULL,
    phone VARCHAR(20) NULL,
    passwd VARCHAR(255) NOT NULL,
    signup_date DATETIME2 NOT NULL CONSTRAINT DF_users_signup_date DEFAULT SYSDATETIME(),
    last_login DATETIME2 NULL,
    is_admin BIT NOT NULL CONSTRAINT DF_users_is_admin DEFAULT 0
);
END
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_users_email' AND object_id = OBJECT_ID(N'dbo.users'))
    CREATE UNIQUE INDEX UX_users_email ON dbo.users(email);

IF OBJECT_ID(N'dbo.author', N'U') IS NULL
BEGIN
CREATE TABLE dbo.author (
    author_id INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_author PRIMARY KEY,
    author_name NVARCHAR(100) NULL,
    date_of_birth DATE NULL
);
END

IF OBJECT_ID(N'dbo.book_author', N'U') IS NULL
BEGIN
CREATE TABLE dbo.book_author (
    bookid INT NOT NULL,
    author_id INT NOT NULL,
    CONSTRAINT PK_book_author PRIMARY KEY (bookid, author_id),
    CONSTRAINT FK_book_author_books FOREIGN KEY (bookid) REFERENCES dbo.books(bookid) ON DELETE CASCADE,
    CONSTRAINT FK_book_author_author FOREIGN KEY (author_id) REFERENCES dbo.author(author_id)
);
END

IF OBJECT_ID(N'dbo.rating', N'U') IS NULL
BEGIN
CREATE TABLE dbo.rating (
    userid INT NOT NULL,
    bookid INT NOT NULL,
    rating TINYINT NULL CONSTRAINT CK_rating_value CHECK (rating BETWEEN 1 AND 5),
    review_text NVARCHAR(MAX) NULL,
    CONSTRAINT PK_rating PRIMARY KEY (userid, bookid),
    CONSTRAINT FK_rating_users FOREIGN KEY (userid) REFERENCES dbo.users(id) ON DELETE CASCADE,
    CONSTRAINT FK_rating_books FOREIGN KEY (bookid) REFERENCES dbo.books(bookid) ON DELETE CASCADE
);
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.author)
BEGIN
INSERT INTO dbo.author(author_name, date_of_birth) VALUES
(N'Nguyễn Nhật Ánh', '1955-05-07'),
(N'J. K. Rowling', '1965-07-31'),
(N'Dale Carnegie', '1888-11-24'),
(N'Robert C. Martin', '1952-12-05');
END

IF NOT EXISTS (SELECT 1 FROM dbo.books)
BEGIN
INSERT INTO dbo.books(isbn, title, publisher, price, description, publish_date, cover_image, quantity) VALUES
('9786041123451', N'Mắt biếc', N'Nhà xuất bản Trẻ', 125.00, N'Câu chuyện tuổi mới lớn giàu cảm xúc.', '2019-01-15', '/assets/images/book-default.svg', 18),
('9786041123452', N'Tôi thấy hoa vàng trên cỏ xanh', N'Nhà xuất bản Trẻ', 135.00, N'Thế giới tuổi thơ trong trẻo và nhiều rung động.', '2020-03-20', '/assets/images/book-default.svg', 22),
('9786041123453', N'Cô gái đến từ hôm qua', N'Nhà xuất bản Trẻ', 110.00, N'Một câu chuyện nhẹ nhàng về ký ức học trò.', '2018-06-08', '/assets/images/book-default.svg', 15),
('9786041123454', N'Cho tôi xin một vé đi tuổi thơ', N'Nhà xuất bản Trẻ', 120.00, N'Hành trình trở về miền ký ức tuổi thơ.', '2021-09-12', '/assets/images/book-default.svg', 20),
('9786041123455', N'Kính vạn hoa', N'Nhà xuất bản Kim Đồng', 145.00, N'Những cuộc phiêu lưu vui nhộn của tuổi học trò.', '2017-05-01', '/assets/images/book-default.svg', 12),
('9786041123456', N'Harry Potter và Hòn đá Phù thủy', N'Nhà xuất bản Trẻ', 210.00, N'Khởi đầu hành trình tại trường Hogwarts.', '2022-01-10', '/assets/images/book-default.svg', 25),
('9786041123457', N'Harry Potter và Phòng chứa Bí mật', N'Nhà xuất bản Trẻ', 225.00, N'Năm học thứ hai đầy bí ẩn tại Hogwarts.', '2022-02-14', '/assets/images/book-default.svg', 19),
('9786041123458', N'Harry Potter và Tù nhân Azkaban', N'Nhà xuất bản Trẻ', 235.00, N'Bí mật về quá khứ của Harry dần hé lộ.', '2022-03-18', '/assets/images/book-default.svg', 17),
('9786041123459', N'Harry Potter và Chiếc cốc lửa', N'Nhà xuất bản Trẻ', 250.00, N'Giải đấu Tam Pháp Thuật đầy thử thách.', '2022-04-22', '/assets/images/book-default.svg', 14),
('9786041123460', N'Đắc nhân tâm', N'Nhà xuất bản Tổng hợp TP HCM', 160.00, N'Những nguyên tắc giao tiếp và ứng xử kinh điển.', '2020-07-11', '/assets/images/book-default.svg', 30),
('9786041123461', N'Quẳng gánh lo đi và vui sống', N'Nhà xuất bản Tổng hợp TP HCM', 150.00, N'Phương pháp thực tế để quản trị nỗi lo.', '2020-08-16', '/assets/images/book-default.svg', 24),
('9786041123462', N'Nghệ thuật nói trước công chúng', N'Nhà xuất bản Lao động', 170.00, N'Rèn luyện sự tự tin và kỹ năng thuyết trình.', '2019-10-05', '/assets/images/book-default.svg', 11),
('9786041123463', N'Clean Code', N'Pearson', 320.00, N'Nguyên tắc viết mã sạch, dễ đọc và dễ bảo trì.', '2008-08-01', '/assets/images/book-default.svg', 16),
('9786041123464', N'Clean Architecture', N'Pearson', 340.00, N'Cấu trúc hệ thống phần mềm bền vững.', '2017-09-20', '/assets/images/book-default.svg', 13);
END

IF NOT EXISTS (SELECT 1 FROM dbo.book_author)
BEGIN
INSERT INTO dbo.book_author(bookid, author_id) VALUES
(1,1),(2,1),(3,1),(4,1),(5,1),(5,3),
(6,2),(7,2),(8,2),(9,2),(9,1),
(10,3),(10,4),(11,3),(12,3),(12,4),
(13,4),(14,4),(14,3);
END

-- Mật khẩu mẫu được lưu dưới dạng BCrypt; mật khẩu rõ chỉ được công bố trong README để chấm bài.
IF NOT EXISTS (SELECT 1 FROM dbo.users)
BEGIN
INSERT INTO dbo.users(email, fullname, phone, passwd, signup_date, last_login, is_admin) VALUES
('admin@bookstore.local', N'Quản trị viên', '0900000001', '$2a$12$zXTd9LMKjucEVm1z5IdjhuFBy9Q2Uchfp.Xz2zS3nG0bBySIYWi1u', SYSDATETIME(), NULL, 1),
('user@bookstore.local', N'Người dùng mẫu', '0900000002', '$2a$12$PlwzUD1abUwp9y90t.H1JeJtqN0H5rZlzSGZME.QJr6BEe/eBEBbW', SYSDATETIME(), NULL, 0);
END

IF NOT EXISTS (SELECT 1 FROM dbo.rating)
BEGIN
INSERT INTO dbo.rating(userid, bookid, rating, review_text) VALUES
(1,1,5,N'Một cuốn sách giàu cảm xúc và đáng đọc.'),
(2,1,4,N'Câu chuyện đẹp, trình bày dễ đọc.'),
(2,2,5,N'Không khí tuổi thơ rất gần gũi.'),
(1,6,5,N'Mở đầu hấp dẫn cho một thế giới kỳ ảo.'),
(2,10,4,N'Nhiều lời khuyên thực tế cho giao tiếp.'),
(1,13,5,N'Nội dung nền tảng cho lập trình viên.'),
(2,14,4,N'Giải thích kiến trúc rõ và có hệ thống.');
END
GO

USE [master];
GO
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'$(AppLogin)')
BEGIN
    DECLARE @createLogin NVARCHAR(MAX) = N'CREATE LOGIN [' + REPLACE(N'$(AppLogin)', N']', N']]')
        + N'] WITH PASSWORD = N''' + REPLACE(N'$(AppLoginPassword)', N'''', N'''''')
        + N''', CHECK_POLICY = OFF;';
    EXEC sp_executesql @createLogin;
END
GO

USE [$(DatabaseName)];
GO
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N'$(AppLogin)')
    EXEC(N'CREATE USER [' + '$(AppLogin)' + N'] FOR LOGIN [' + '$(AppLogin)' + N']');
ALTER ROLE db_datareader ADD MEMBER [$(AppLogin)];
ALTER ROLE db_datawriter ADD MEMBER [$(AppLogin)];
GO

SELECT 'Database ready' AS status,
       (SELECT COUNT(*) FROM dbo.books) AS books,
       (SELECT COUNT(*) FROM dbo.author) AS authors,
       (SELECT COUNT(*) FROM dbo.users) AS users,
       (SELECT COUNT(*) FROM dbo.rating) AS ratings;
GO
