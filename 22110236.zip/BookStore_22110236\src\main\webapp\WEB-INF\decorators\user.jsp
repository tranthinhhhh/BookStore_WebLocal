<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><sitemesh:write property="title"/> - BookStore</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/app.css">
    <sitemesh:write property="head"/>
</head>
<body>
<header class="site-header">
    <div class="container nav-wrap">
        <a class="brand" href="${pageContext.request.contextPath}/home">BookStore <span>22110236</span></a>
        <nav class="main-nav" aria-label="Điều hướng chính">
            <a href="${pageContext.request.contextPath}/home">Trang chủ</a>
            <a href="${pageContext.request.contextPath}/products">Sản phẩm</a>
            <c:choose>
                <c:when test="${empty sessionScope.currentUser}">
                    <a href="${pageContext.request.contextPath}/login">Đăng nhập</a>
                </c:when>
                <c:otherwise>
                    <span class="welcome">Xin chào, <c:out value="${sessionScope.currentUser.fullName}"/></span>
                    <form class="nav-form" method="post" action="${pageContext.request.contextPath}/logout">
                        <button class="link-button" type="submit">Đăng xuất</button>
                    </form>
                </c:otherwise>
            </c:choose>
            <c:if test="${not empty sessionScope.currentUser and sessionScope.currentUser.admin}">
                <a class="admin-link" href="${pageContext.request.contextPath}/admin/books">Trang quản trị</a>
            </c:if>
        </nav>
    </div>
</header>
<main class="container main-content">
    <sitemesh:write property="body"/>
</main>
<footer class="site-footer">
    <div class="container">Trần Tiến Thịnh – 22110236 – Đề 02</div>
</footer>
</body>
</html>
