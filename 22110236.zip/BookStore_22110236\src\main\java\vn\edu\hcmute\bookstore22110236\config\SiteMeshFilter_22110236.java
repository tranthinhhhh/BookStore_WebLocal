package vn.edu.hcmute.bookstore22110236.config;

import org.sitemesh.builder.SiteMeshFilterBuilder;
import org.sitemesh.config.ConfigurableSiteMeshFilter;

public class SiteMeshFilter_22110236 extends ConfigurableSiteMeshFilter {
    @Override
    protected void applyCustomConfiguration(SiteMeshFilterBuilder builder) {
        builder.addExcludedPath("/assets/*")
                .addExcludedPath("/favicon.ico")
                .addDecoratorPath("/admin/*", "admin.jsp")
                .addDecoratorPath("/*", "user.jsp");
    }
}
