<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html><head><title>Lỗi hệ thống</title></head><body><section class="panel empty-state"><h1>Đã xảy ra lỗi</h1><p>Ứng dụng không thể xử lý yêu cầu. Hãy kiểm tra kết nối cơ sở dữ liệu và thử lại.</p><a class="button" href="${pageContext.request.contextPath}/home">Về trang chủ</a></section></body></html>
