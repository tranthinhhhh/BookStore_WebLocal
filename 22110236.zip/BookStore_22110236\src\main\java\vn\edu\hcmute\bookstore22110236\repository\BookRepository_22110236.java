package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.config.DatabaseConnection_22110236;
import vn.edu.hcmute.bookstore22110236.model.Author_22110236;
import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.PageResult_22110236;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BookRepository_22110236 implements IBookRepository_22110236 {
    private static final String BOOK_COLUMNS = "b.bookid, b.isbn, b.title, b.publisher, b.price, "
            + "b.description, b.publish_date, b.cover_image, b.quantity";

    @Override
    public List<Author_22110236> findAllAuthors() {
        List<Author_22110236> authors = new ArrayList<>();
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT author_id, author_name, date_of_birth FROM author ORDER BY author_name");
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) authors.add(mapAuthor(resultSet));
            return authors;
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tải danh sách tác giả.", exception);
        }
    }

    @Override
    public PageResult_22110236<Book_22110236> findByAuthor(int authorId, int page, int pageSize) {
        String countSql = "SELECT COUNT(*) FROM book_author WHERE author_id = ?";
        String dataSql = "SELECT " + BOOK_COLUMNS + ", COUNT(r.userid) AS review_count "
                + "FROM books b JOIN book_author ba ON ba.bookid = b.bookid "
                + "LEFT JOIN rating r ON r.bookid = b.bookid WHERE ba.author_id = ? "
                + "GROUP BY " + BOOK_COLUMNS + " ORDER BY b.title "
                + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        try (Connection connection = DatabaseConnection_22110236.getConnection()) {
            long total = queryCount(connection, countSql, authorId);
            int safePage = normalizePage(page, total, pageSize);
            List<Book_22110236> books = queryBooks(connection, dataSql,
                    statement -> {
                        statement.setInt(1, authorId);
                        statement.setInt(2, (safePage - 1) * pageSize);
                        statement.setInt(3, pageSize);
                    });
            return new PageResult_22110236<>(books, safePage, pageSize, total);
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tải sách theo tác giả.", exception);
        }
    }

    @Override
    public PageResult_22110236<Book_22110236> findAll(int page, int pageSize) {
        String dataSql = "SELECT " + BOOK_COLUMNS + ", COUNT(r.userid) AS review_count "
                + "FROM books b LEFT JOIN rating r ON r.bookid = b.bookid "
                + "GROUP BY " + BOOK_COLUMNS + " ORDER BY b.bookid DESC "
                + "OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
        try (Connection connection = DatabaseConnection_22110236.getConnection()) {
            long total = queryCount(connection, "SELECT COUNT(*) FROM books", null);
            int safePage = normalizePage(page, total, pageSize);
            List<Book_22110236> books = queryBooks(connection, dataSql,
                    statement -> {
                        statement.setInt(1, (safePage - 1) * pageSize);
                        statement.setInt(2, pageSize);
                    });
            return new PageResult_22110236<>(books, safePage, pageSize, total);
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tải danh sách sách.", exception);
        }
    }

    @Override
    public Optional<Book_22110236> findById(int bookId) {
        String sql = "SELECT " + BOOK_COLUMNS + ", COUNT(r.userid) AS review_count "
                + "FROM books b LEFT JOIN rating r ON r.bookid = b.bookid WHERE b.bookid = ? "
                + "GROUP BY " + BOOK_COLUMNS;
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookId);
            Book_22110236 book;
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) return Optional.empty();
                book = mapBook(resultSet);
            }
            book.setAuthors(loadAuthors(connection, bookId));
            return Optional.of(book);
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tải chi tiết sách.", exception);
        }
    }

    @Override
    public boolean isbnExists(String isbn, int excludedBookId) {
        String sql = "SELECT COUNT(*) FROM books WHERE isbn = ? AND bookid <> ?";
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, isbn);
            statement.setInt(2, excludedBookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() && resultSet.getInt(1) > 0;
            }
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể kiểm tra ISBN.", exception);
        }
    }

    @Override
    public int create(Book_22110236 book, List<Integer> authorIds) {
        String sql = "INSERT INTO books(isbn, title, publisher, price, description, publish_date, cover_image, quantity) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection_22110236.getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                bindBook(statement, book);
                statement.executeUpdate();
                try (ResultSet keys = statement.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Không nhận được bookid vừa tạo.");
                    book.setBookId(keys.getInt(1));
                }
                replaceAuthors(connection, book.getBookId(), authorIds);
                connection.commit();
                return book.getBookId();
            } catch (SQLException exception) {
                rollback(connection);
                throw exception;
            }
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể thêm sách; hãy kiểm tra ISBN và tác giả.", exception);
        }
    }

    @Override
    public void update(Book_22110236 book, List<Integer> authorIds) {
        String sql = "UPDATE books SET isbn=?, title=?, publisher=?, price=?, description=?, "
                + "publish_date=?, cover_image=?, quantity=? WHERE bookid=?";
        try (Connection connection = DatabaseConnection_22110236.getConnection()) {
            connection.setAutoCommit(false);
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                bindBook(statement, book);
                statement.setInt(9, book.getBookId());
                if (statement.executeUpdate() == 0) throw new SQLException("Sách không còn tồn tại.");
                replaceAuthors(connection, book.getBookId(), authorIds);
                connection.commit();
            } catch (SQLException exception) {
                rollback(connection);
                throw exception;
            }
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể cập nhật sách; hãy kiểm tra ISBN và tác giả.", exception);
        }
    }

    @Override
    public void delete(int bookId) {
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement("DELETE FROM books WHERE bookid = ?")) {
            statement.setInt(1, bookId);
            if (statement.executeUpdate() == 0) {
                throw new RepositoryException_22110236("Sách không tồn tại hoặc đã bị xóa.", null);
            }
        } catch (SQLException exception) {
            throw new RepositoryException_22110236(
                    "Không thể xóa sách do dữ liệu liên quan hoặc lỗi cơ sở dữ liệu.", exception);
        }
    }

    private List<Book_22110236> queryBooks(Connection connection, String sql, StatementBinder binder)
            throws SQLException {
        List<Book_22110236> books = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            binder.bind(statement);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    books.add(mapBook(resultSet));
                }
            }
        }
        for (Book_22110236 book : books) {
            book.setAuthors(loadAuthors(connection, book.getBookId()));
        }
        return books;
    }

    private List<Author_22110236> loadAuthors(Connection connection, int bookId) throws SQLException {
        String sql = "SELECT a.author_id, a.author_name, a.date_of_birth FROM author a "
                + "JOIN book_author ba ON ba.author_id = a.author_id WHERE ba.bookid = ? ORDER BY a.author_name";
        List<Author_22110236> authors = new ArrayList<>();
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) authors.add(mapAuthor(resultSet));
            }
        }
        return authors;
    }

    private long queryCount(Connection connection, String sql, Integer parameter) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            if (parameter != null) statement.setInt(1, parameter);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? resultSet.getLong(1) : 0;
            }
        }
    }

    private int normalizePage(int requestedPage, long total, int pageSize) {
        int totalPages = Math.max(1, (int) Math.ceil((double) total / pageSize));
        return Math.max(1, Math.min(requestedPage, totalPages));
    }

    private Book_22110236 mapBook(ResultSet resultSet) throws SQLException {
        Book_22110236 book = new Book_22110236();
        book.setBookId(resultSet.getInt("bookid"));
        book.setIsbn(resultSet.getString("isbn"));
        book.setTitle(resultSet.getString("title"));
        book.setPublisher(resultSet.getString("publisher"));
        book.setPrice(resultSet.getBigDecimal("price"));
        book.setDescription(resultSet.getString("description"));
        Date publishDate = resultSet.getDate("publish_date");
        if (publishDate != null) book.setPublishDate(publishDate.toLocalDate());
        book.setCoverImage(resultSet.getString("cover_image"));
        book.setQuantity(resultSet.getInt("quantity"));
        book.setReviewCount(resultSet.getLong("review_count"));
        return book;
    }

    private Author_22110236 mapAuthor(ResultSet resultSet) throws SQLException {
        Date birthDate = resultSet.getDate("date_of_birth");
        return new Author_22110236(resultSet.getInt("author_id"), resultSet.getString("author_name"),
                birthDate == null ? null : birthDate.toLocalDate());
    }

    private void bindBook(PreparedStatement statement, Book_22110236 book) throws SQLException {
        statement.setString(1, book.getIsbn());
        statement.setString(2, book.getTitle());
        statement.setString(3, book.getPublisher());
        statement.setBigDecimal(4, book.getPrice());
        statement.setString(5, book.getDescription());
        statement.setDate(6, book.getPublishDate() == null ? null : Date.valueOf(book.getPublishDate()));
        statement.setString(7, book.getCoverImage());
        statement.setInt(8, book.getQuantity());
    }

    private void replaceAuthors(Connection connection, int bookId, List<Integer> authorIds) throws SQLException {
        try (PreparedStatement delete = connection.prepareStatement("DELETE FROM book_author WHERE bookid = ?")) {
            delete.setInt(1, bookId);
            delete.executeUpdate();
        }
        try (PreparedStatement insert = connection.prepareStatement(
                "INSERT INTO book_author(bookid, author_id) VALUES (?, ?)")) {
            for (Integer authorId : authorIds) {
                insert.setInt(1, bookId);
                insert.setInt(2, authorId);
                insert.addBatch();
            }
            insert.executeBatch();
        }
    }

    private void rollback(Connection connection) {
        try {
            connection.rollback();
        } catch (SQLException ignored) {
        }
    }

    @FunctionalInterface
    private interface StatementBinder {
        void bind(PreparedStatement statement) throws SQLException;
    }
}
