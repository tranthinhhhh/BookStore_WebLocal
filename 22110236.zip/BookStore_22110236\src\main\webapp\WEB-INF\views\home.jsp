<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>Trang chủ</title></head>
<body>
<section>
    <h1>Sách theo từng tác giả</h1>
    <p class="lead">Mỗi trang hiển thị đúng 3 sách. Chọn tác giả để xem danh sách và chuyển trang độc lập.</p>

    <c:choose>
        <c:when test="${empty authors}">
            <div class="panel empty-state">Chưa có tác giả hoặc sách trong cơ sở dữ liệu.</div>
        </c:when>
        <c:otherwise>
            <nav class="author-tabs" aria-label="Chọn tác giả">
                <c:forEach var="author" items="${authors}">
                    <a class="author-tab ${selectedAuthor.authorId == author.authorId ? 'active' : ''}"
                       href="${pageContext.request.contextPath}/home?authorId=${author.authorId}&amp;page=1">
                        <c:out value="${author.authorName}"/>
                    </a>
                </c:forEach>
            </nav>
            <h2>Tác giả: <c:out value="${selectedAuthor.authorName}"/></h2>
            <c:choose>
                <c:when test="${empty bookPage.items}">
                    <div class="panel empty-state">Tác giả này chưa có sách.</div>
                </c:when>
                <c:otherwise>
                    <div class="book-grid">
                        <c:forEach var="book" items="${bookPage.items}">
                            <article class="book-card">
                                <img class="book-cover" loading="lazy"
                                     src="${pageContext.request.contextPath}${book.coverImage}"
                                     alt="Bìa sách ${book.title}">
                                <div class="book-card-body">
                                    <a class="book-title" href="${pageContext.request.contextPath}/books/detail?id=${book.bookId}">
                                        <c:out value="${book.title}"/>
                                    </a>
                                    <dl class="book-meta">
                                        <dt>Mã ISBN</dt><dd><c:out value="${book.isbn}"/></dd>
                                        <dt>Tác giả</dt><dd><c:out value="${book.authorsText}"/></dd>
                                        <dt>Publisher</dt><dd><c:out value="${book.publisher}"/></dd>
                                        <dt>Publish date</dt><dd><c:out value="${book.publishDate}"/></dd>
                                        <dt>Quantity</dt><dd><c:out value="${book.quantity}"/></dd>
                                    </dl>
                                    <div class="review-count">Review (<c:out value="${book.reviewCount}"/>)</div>
                                </div>
                            </article>
                        </c:forEach>
                    </div>
                    <nav class="pagination" aria-label="Phân trang sách">
                        <c:choose>
                            <c:when test="${bookPage.hasPrevious}">
                                <a href="?authorId=${selectedAuthor.authorId}&amp;page=${bookPage.page - 1}">Trang trước</a>
                            </c:when>
                            <c:otherwise><span class="disabled">Trang trước</span></c:otherwise>
                        </c:choose>
                        <c:forEach begin="1" end="${bookPage.totalPages}" var="number">
                            <a class="${number == bookPage.page ? 'active' : ''}"
                               href="?authorId=${selectedAuthor.authorId}&amp;page=${number}">${number}</a>
                        </c:forEach>
                        <c:choose>
                            <c:when test="${bookPage.hasNext}">
                                <a href="?authorId=${selectedAuthor.authorId}&amp;page=${bookPage.page + 1}">Trang sau</a>
                            </c:when>
                            <c:otherwise><span class="disabled">Trang sau</span></c:otherwise>
                        </c:choose>
                    </nav>
                </c:otherwise>
            </c:choose>
        </c:otherwise>
    </c:choose>
</section>
</body>
</html>
