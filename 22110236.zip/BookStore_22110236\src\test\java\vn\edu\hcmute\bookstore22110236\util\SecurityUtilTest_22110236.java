package vn.edu.hcmute.bookstore22110236.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SecurityUtilTest_22110236 {
    @Test
    void passwordIsHashedAndVerified() {
        String hash = PasswordUtil_22110236.hash("Secure@123");
        assertNotEquals("Secure@123", hash);
        assertTrue(PasswordUtil_22110236.verify("Secure@123", hash));
        assertFalse(PasswordUtil_22110236.verify("wrong", hash));
    }

    @Test
    void otpDigestMatchesOnlyCorrectCode() {
        String digest = OtpUtil_22110236.digest("123456");
        assertTrue(OtpUtil_22110236.matches("123456", digest));
        assertFalse(OtpUtil_22110236.matches("654321", digest));
    }
}
