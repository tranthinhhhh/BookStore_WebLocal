<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head><title>${book.bookId == 0 ? 'Thêm sách' : 'Cập nhật sách'}</title></head>
<body>
<section class="form-card">
    <h1>${book.bookId == 0 ? 'Thêm sách' : 'Cập nhật sách'}</h1>
    <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
    <form method="post" action="${pageContext.request.contextPath}/admin/books/save">
        <input type="hidden" name="bookId" value="${book.bookId}">
        <div class="form-group"><label for="isbn">ISBN</label><input id="isbn" name="isbn" maxlength="20" value="<c:out value='${book.isbn}'/>" required></div>
        <div class="form-group"><label for="title">Tiêu đề</label><input id="title" name="title" maxlength="200" value="<c:out value='${book.title}'/>" required></div>
        <div class="form-group"><label for="publisher">Nhà xuất bản</label><input id="publisher" name="publisher" maxlength="100" value="<c:out value='${book.publisher}'/>" required></div>
        <div class="form-group"><label for="price">Giá</label><input id="price" type="number" name="price" min="0" max="9999.99" step="0.01" value="${book.price}" required></div>
        <div class="form-group"><label for="publishDate">Ngày xuất bản</label><input id="publishDate" type="date" name="publishDate" value="${book.publishDate}"></div>
        <div class="form-group"><label for="quantity">Số lượng</label><input id="quantity" type="number" name="quantity" min="0" value="${book.quantity}" required></div>
        <div class="form-group"><label for="coverImage">Đường dẫn ảnh bìa</label><input id="coverImage" name="coverImage" maxlength="255" value="<c:out value='${book.coverImage}'/>" placeholder="/assets/images/book-default.svg"></div>
        <div class="form-group"><label for="description">Mô tả</label><textarea id="description" name="description" maxlength="4000"><c:out value="${book.description}"/></textarea></div>
        <div class="form-group">
            <label>Tác giả</label>
            <div class="checkbox-list">
                <c:forEach var="author" items="${authors}">
                    <label><input type="checkbox" name="authorIds" value="${author.authorId}" ${selectedAuthorIds.contains(author.authorId) ? 'checked' : ''}> <c:out value="${author.authorName}"/></label>
                </c:forEach>
            </div>
        </div>
        <div class="actions"><button class="button" type="submit">Lưu sách</button><a class="button secondary" href="${pageContext.request.contextPath}/admin/books">Hủy</a></div>
    </form>
</section>
</body>
</html>
