<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html><head><title>Đăng nhập</title></head><body>
<section class="form-card">
    <h1>Đăng nhập</h1>
    <p class="lead">Đăng nhập để đánh giá sách hoặc sử dụng chức năng quản trị.</p>
    <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
    <c:if test="${param.error == 'forbidden'}"><div class="alert error">Bạn cần tài khoản Admin để truy cập trang quản trị.</div></c:if>
    <c:if test="${param.error == 'loginRequired'}"><div class="alert error">Vui lòng đăng nhập trước khi đánh giá.</div></c:if>
    <c:if test="${param.registered == 'success'}"><div class="alert success">Kích hoạt thành công. Bạn có thể đăng nhập.</div></c:if>
    <c:if test="${param.logout == 'success'}"><div class="alert success">Bạn đã đăng xuất.</div></c:if>
    <form method="post" action="${pageContext.request.contextPath}/login">
        <div class="form-group"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="254" value="<c:out value='${email}'/>" required autofocus></div>
        <div class="form-group"><label for="password">Mật khẩu</label><input id="password" type="password" name="password" minlength="8" maxlength="72" required></div>
        <button class="button" type="submit">Đăng nhập</button>
    </form>
    <p class="auth-links">Chưa có tài khoản? <a href="${pageContext.request.contextPath}/register">Đăng ký</a></p>
</section>
</body></html>
