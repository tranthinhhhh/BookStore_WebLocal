package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.Author_22110236;
import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.PageResult_22110236;
import vn.edu.hcmute.bookstore22110236.service.BookService_22110236;
import vn.edu.hcmute.bookstore22110236.service.IBookService_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = {"/home", "/products"})
public class HomeController_22110236 extends HttpServlet {
    private final IBookService_22110236 bookService = new BookService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Author_22110236> authors = bookService.getAuthors();
        if (authors.isEmpty()) {
            request.setAttribute("authors", authors);
            request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
            return;
        }
        int requestedAuthorId = ControllerUtil_22110236.parseInt(
                request.getParameter("authorId"), authors.get(0).getAuthorId());
        Author_22110236 selected = authors.stream()
                .filter(author -> author.getAuthorId() == requestedAuthorId)
                .findFirst().orElse(authors.get(0));
        int page = ControllerUtil_22110236.parseInt(request.getParameter("page"), 1);
        PageResult_22110236<Book_22110236> result =
                bookService.getBooksByAuthor(selected.getAuthorId(), page);
        request.setAttribute("authors", authors);
        request.setAttribute("selectedAuthor", selected);
        request.setAttribute("bookPage", result);
        request.getRequestDispatcher("/WEB-INF/views/home.jsp").forward(request, response);
    }
}
