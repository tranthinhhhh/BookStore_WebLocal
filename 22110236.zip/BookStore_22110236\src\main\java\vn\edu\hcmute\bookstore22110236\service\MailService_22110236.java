package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.config.AppConfig_22110236;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class MailService_22110236 {
    public boolean isSmtpEnabled() {
        return AppConfig_22110236.getBoolean("SMTP_ENABLED", false);
    }

    public void sendOtp(String recipient, String otp) {
        if (!isSmtpEnabled()) {
            System.out.printf("[DEV OTP] %s -> %s%n", recipient, otp);
            return;
        }
        String host = AppConfig_22110236.get("SMTP_HOST");
        String port = AppConfig_22110236.get("SMTP_PORT");
        String username = AppConfig_22110236.get("SMTP_USERNAME");
        String password = AppConfig_22110236.get("SMTP_PASSWORD");
        String from = AppConfig_22110236.get("SMTP_FROM");
        if (host.isBlank() || port.isBlank() || username.isBlank() || password.isBlank() || from.isBlank()) {
            throw new ServiceException_22110236("Cấu hình SMTP chưa đầy đủ.");
        }

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable",
                String.valueOf(AppConfig_22110236.getBoolean("SMTP_STARTTLS", true)));
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);
        properties.put("mail.smtp.connectiontimeout", "10000");
        properties.put("mail.smtp.timeout", "10000");

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });
        try {
            MimeMessage message = new MimeMessage(session);
            message.setFrom(new InternetAddress(from));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient, false));
            message.setSubject("Mã OTP kích hoạt BookStore 22110236", "UTF-8");
            message.setText("Mã OTP của bạn là: " + otp + "\nMã có hiệu lực trong 5 phút.", "UTF-8");
            Transport.send(message);
        } catch (MessagingException exception) {
            throw new ServiceException_22110236("Không gửi được OTP. Vui lòng kiểm tra cấu hình SMTP.", exception);
        }
    }
}
