<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html><head><title>Xác nhận OTP</title></head><body>
<section class="form-card">
    <h1>Xác nhận OTP</h1>
    <p class="lead">Nhập mã đã gửi đến <strong><c:out value="${pendingEmail}"/></strong>. Mã hết hạn sau 5 phút.</p>
    <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
    <c:if test="${not empty devOtp}"><div class="alert info">Chế độ phát triển chưa cấu hình SMTP. OTP kiểm thử: <strong><c:out value="${devOtp}"/></strong></div></c:if>
    <form method="post" action="${pageContext.request.contextPath}/verify-otp">
        <div class="form-group"><label for="otp">Mã OTP</label><input id="otp" name="otp" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autofocus></div>
        <button class="button" type="submit">Kích hoạt tài khoản</button>
    </form>
</section>
</body></html>
