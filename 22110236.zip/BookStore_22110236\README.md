# BookStore 22110236 - Đề 02

Sinh viên: **Trần Tiến Thịnh**  
MSSV: **22110236**  
Mã đề: **02**

Ứng dụng Maven WAR dùng Java Servlet, JSP/JSTL, JDBC SQL Server và SiteMesh 3. Mã nguồn được chia thành Presentation/MVC, Business/Service và Data Access/Repository.

## Môi trường tương thích

- JDK 17
- Maven 3.9.x
- Apache Tomcat 9.x (Servlet `javax.*`)
- Microsoft SQL Server 2019 trở lên; đã chạy thử với SQL Server 2025 Developer

## 1. Import cơ sở dữ liệu

Script: `database/BookStore_22110236.sql`.

Mở PowerShell tại thư mục project và chạy bằng tài khoản Windows có quyền tạo database/login. Luôn dùng `-f 65001` để giữ đúng dữ liệu tiếng Việt:

```powershell
sqlcmd -S localhost -E -C -f 65001 -v AppLoginPassword="<MAT_KHAU_DB_CUC_BO>" -i ".\database\BookStore_22110236.sql"
```

Script tạo database `BookStore_22110236`, login `bookstore_app`, đầy đủ khóa chính/khóa ngoại, khóa ghép của `book_author` và `rating`, cùng 14 sách, 4 tác giả, dữ liệu nhiều tác giả và review mẫu. Script không xóa dữ liệu đang có và có thể chạy lại.

Các điều chỉnh kiểu dữ liệu tối thiểu so với hình đề:

- `isbn`: `INT` thành `VARCHAR(20)` để giữ số 0 đầu, ISBN-10/ISBN-13 và tránh tràn số.
- `phone`: `INT` thành `VARCHAR(20)` để giữ số 0 đầu và mã quốc gia.
- `passwd`: `VARCHAR(32)` thành `VARCHAR(255)` để lưu BCrypt; tuyệt đối không lưu mật khẩu rõ.
- `email`: tăng lên `VARCHAR(254)`, `fullname` lên `NVARCHAR(100)` để kiểm tra dữ liệu thực tế.
- `description`, `review_text`: dùng `NVARCHAR(MAX)` thay cho `TEXT` đã cũ và hỗ trợ Unicode.
- `cover_image`: tăng lên `VARCHAR(255)`; các cột thời gian dùng `DATETIME2`.

Chỉ các khóa thực thể `bookid`, `users.id`, `author_id` dùng `IDENTITY`. Hai bảng liên kết giữ khóa chính ghép; các cột khóa ngoại trong khóa ghép không tự tăng.

## 2. Cấu hình ứng dụng

Ứng dụng đọc biến môi trường trước, sau đó mới dùng giá trị mặc định trong `src/main/resources/application.properties`. Không lưu mật khẩu thật vào project.

Ví dụ PowerShell trước khi chạy Tomcat:

```powershell
$env:DB_URL="jdbc:sqlserver://localhost:1433;databaseName=BookStore_22110236;encrypt=true;trustServerCertificate=true"
$env:DB_USER="bookstore_app"
$env:DB_PASSWORD="<MAT_KHAU_DB_CUC_BO>"
```

## 3. Cấu hình SMTP và OTP

Mặc định `SMTP_ENABLED=false`. Ở chế độ này ứng dụng vẫn tạo, kiểm tra sai/đúng, giới hạn 5 lần và hết hạn OTP; mã OTP được hiển thị trên trang xác nhận để kiểm thử cục bộ.

Để gửi email thật, đặt các biến sau rồi khởi động lại Tomcat:

```powershell
$env:SMTP_ENABLED="true"
$env:SMTP_HOST="smtp.gmail.com"
$env:SMTP_PORT="587"
$env:SMTP_USERNAME="<EMAIL_GUI>"
$env:SMTP_PASSWORD="<APP_PASSWORD>"
$env:SMTP_FROM="<EMAIL_GUI>"
$env:SMTP_STARTTLS="true"
$env:OTP_EXPIRY_MINUTES="5"
```

Nếu dùng Gmail, sử dụng App Password thay cho mật khẩu tài khoản. Chức năng gửi qua SMTP thật **chưa được kiểm chứng** vì không có tài khoản SMTP trong môi trường chạy; toàn bộ luồng OTP ở chế độ phát triển đã được kiểm thử.

## 4. Build và chạy

```powershell
mvn clean package
```

Copy `target/bookstore-22110236.war` vào thư mục `webapps` của Tomcat 9, đặt các biến môi trường ở trên và chạy Tomcat. URL:

- Trang chủ: `http://localhost:8080/bookstore-22110236/home`
- Đăng nhập: `http://localhost:8080/bookstore-22110236/login`
- Đăng ký: `http://localhost:8080/bookstore-22110236/register`
- Quản trị sách: `http://localhost:8080/bookstore-22110236/admin/books`

## 5. Tài khoản mẫu

- Admin: `admin@bookstore.local` / `Admin@123`
- User: `user@bookstore.local` / `User@123`

Mật khẩu trong database là chuỗi BCrypt. Menu và mọi URL thêm/sửa/xóa đều được kiểm tra quyền Admin ở phía server.

## 6. Chức năng và trạng thái kiểm thử

- Trang chủ theo từng tác giả, đúng 3 sách/trang; phân trang giữ đúng tác giả.
- Chi tiết sách, hiển thị review và thêm/cập nhật review khi đã đăng nhập.
- Đăng ký, OTP sai/đúng/hết hạn, email trùng, đăng nhập, đăng xuất, phân quyền User/Admin.
- CRUD sách, tác giả nhiều-nhiều, phân trang 5 sách/trang và xử lý lỗi dữ liệu/khóa ngoại.
- SiteMesh có decorator riêng cho User và Admin; footer đúng thông tin sinh viên.
- Đã chạy `mvn clean package`, unit test và smoke test HTTP trên Tomcat với SQL Server cục bộ.
- Chưa kiểm chứng việc gửi email qua SMTP thật như đã nêu ở mục 3.

## 7. Cấu trúc chính

```text
src/main/java/.../controller       Presentation Controllers
src/main/java/.../service          Business Interfaces/Implementations
src/main/java/.../repository       Data Access Interfaces/Implementations
src/main/java/.../filter           Encoding và phân quyền Admin
src/main/webapp/WEB-INF/views      JSP Views
src/main/webapp/WEB-INF/decorators SiteMesh User/Admin
database/                          SQL Server script
```

Các Class, Interface, Controller và Service đều có hậu tố `_22110236` và tên lớp Java khớp tên file.
