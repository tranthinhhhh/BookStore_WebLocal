package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.model.Author_22110236;
import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.PageResult_22110236;

import java.util.List;
import java.util.Optional;

public interface IBookRepository_22110236 {
    List<Author_22110236> findAllAuthors();
    PageResult_22110236<Book_22110236> findByAuthor(int authorId, int page, int pageSize);
    PageResult_22110236<Book_22110236> findAll(int page, int pageSize);
    Optional<Book_22110236> findById(int bookId);
    boolean isbnExists(String isbn, int excludedBookId);
    int create(Book_22110236 book, List<Integer> authorIds);
    void update(Book_22110236 book, List<Integer> authorIds);
    void delete(int bookId);
}
