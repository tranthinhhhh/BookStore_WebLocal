package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.Rating_22110236;

import java.util.List;

public interface IRatingService_22110236 {
    List<Rating_22110236> getByBookId(int bookId);
    void save(int userId, int bookId, int stars, String reviewText);
}
