package vn.edu.hcmute.bookstore22110236.service;

import vn.edu.hcmute.bookstore22110236.model.Author_22110236;
import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.model.PageResult_22110236;

import java.util.List;
import java.util.Optional;

public interface IBookService_22110236 {
    List<Author_22110236> getAuthors();
    PageResult_22110236<Book_22110236> getBooksByAuthor(int authorId, int page);
    PageResult_22110236<Book_22110236> getBooksForAdmin(int page);
    Optional<Book_22110236> getById(int bookId);
    int save(Book_22110236 book, List<Integer> authorIds);
    void delete(int bookId);
}
