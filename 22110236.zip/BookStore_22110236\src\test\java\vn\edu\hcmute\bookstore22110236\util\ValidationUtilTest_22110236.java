package vn.edu.hcmute.bookstore22110236.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidationUtilTest_22110236 {
    @Test
    void validRegistrationHasNoErrors() {
        assertTrue(ValidationUtil_22110236.validateRegistration(
                "student@example.com", "Trần Tiến Thịnh", "0901234567",
                "Password@123", "Password@123").isEmpty());
    }

    @Test
    void invalidBookIsRejected() {
        assertFalse(ValidationUtil_22110236.validateBook(
                "bad", "", "", new BigDecimal("-1"), -2).isEmpty());
    }
}
