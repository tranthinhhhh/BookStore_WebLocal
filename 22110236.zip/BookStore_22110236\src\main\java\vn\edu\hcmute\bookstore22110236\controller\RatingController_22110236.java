package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.User_22110236;
import vn.edu.hcmute.bookstore22110236.service.IRatingService_22110236;
import vn.edu.hcmute.bookstore22110236.service.RatingService_22110236;
import vn.edu.hcmute.bookstore22110236.service.ServiceException_22110236;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet("/reviews/save")
public class RatingController_22110236 extends HttpServlet {
    private final IRatingService_22110236 ratingService = new RatingService_22110236();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        User_22110236 user = request.getSession(false) == null ? null
                : (User_22110236) request.getSession(false).getAttribute("currentUser");
        int bookId = ControllerUtil_22110236.parseInt(request.getParameter("bookId"), 0);
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login?error=loginRequired");
            return;
        }
        try {
            int stars = ControllerUtil_22110236.parseInt(request.getParameter("rating"), 0);
            ratingService.save(user.getId(), bookId, stars, request.getParameter("reviewText"));
            response.sendRedirect(request.getContextPath() + "/books/detail?id=" + bookId + "&review=success");
        } catch (ServiceException_22110236 exception) {
            response.sendRedirect(request.getContextPath() + "/books/detail?id=" + bookId + "&error="
                    + URLEncoder.encode(exception.getMessage(), StandardCharsets.UTF_8));
        }
    }
}
