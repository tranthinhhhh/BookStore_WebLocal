package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.model.Rating_22110236;

import java.util.List;

public interface IRatingRepository_22110236 {
    List<Rating_22110236> findByBookId(int bookId);
    void saveOrUpdate(Rating_22110236 rating);
}
