package vn.edu.hcmute.bookstore22110236.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Book_22110236 {
    private int bookId;
    private String isbn;
    private String title;
    private String publisher;
    private BigDecimal price;
    private String description;
    private LocalDate publishDate;
    private String coverImage;
    private int quantity;
    private List<Author_22110236> authors = new ArrayList<>();
    private long reviewCount;

    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }
    public BigDecimal getPrice() { return price; }
    public void setPrice(BigDecimal price) { this.price = price; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public LocalDate getPublishDate() { return publishDate; }
    public void setPublishDate(LocalDate publishDate) { this.publishDate = publishDate; }
    public String getCoverImage() { return coverImage; }
    public void setCoverImage(String coverImage) { this.coverImage = coverImage; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public List<Author_22110236> getAuthors() { return authors; }
    public void setAuthors(List<Author_22110236> authors) { this.authors = authors; }
    public long getReviewCount() { return reviewCount; }
    public void setReviewCount(long reviewCount) { this.reviewCount = reviewCount; }

    public String getAuthorsText() {
        return authors.stream().map(Author_22110236::getAuthorName).collect(Collectors.joining(", "));
    }
}
