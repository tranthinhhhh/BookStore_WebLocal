package vn.edu.hcmute.bookstore22110236.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class ValidationUtil_22110236 {
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private static final Pattern PHONE = Pattern.compile("^[0-9+() .-]{8,20}$");
    private static final Pattern ISBN = Pattern.compile("^[0-9Xx -]{10,20}$");

    private ValidationUtil_22110236() {
    }

    public static List<String> validateRegistration(String email, String fullName, String phone,
                                                     String password, String confirmPassword) {
        List<String> errors = new ArrayList<>();
        if (email == null || email.length() > 254 || !EMAIL.matcher(email).matches()) {
            errors.add("Email không hợp lệ.");
        }
        if (fullName == null || fullName.trim().length() < 2 || fullName.length() > 100) {
            errors.add("Họ tên phải có từ 2 đến 100 ký tự.");
        }
        if (phone != null && !phone.isBlank() && !PHONE.matcher(phone).matches()) {
            errors.add("Số điện thoại không hợp lệ.");
        }
        if (password == null || password.length() < 8 || password.length() > 72) {
            errors.add("Mật khẩu phải có từ 8 đến 72 ký tự.");
        }
        if (password == null || !password.equals(confirmPassword)) {
            errors.add("Mật khẩu xác nhận không khớp.");
        }
        return errors;
    }

    public static List<String> validateBook(String isbn, String title, String publisher,
                                            BigDecimal price, int quantity) {
        List<String> errors = new ArrayList<>();
        if (isbn == null || !ISBN.matcher(isbn).matches()) errors.add("ISBN phải có 10-20 ký tự hợp lệ.");
        if (title == null || title.isBlank() || title.length() > 200) errors.add("Tiêu đề là bắt buộc và tối đa 200 ký tự.");
        if (publisher == null || publisher.isBlank() || publisher.length() > 100) errors.add("Nhà xuất bản là bắt buộc và tối đa 100 ký tự.");
        if (price == null || price.signum() < 0 || price.compareTo(new BigDecimal("9999.99")) > 0) errors.add("Giá phải từ 0 đến 9999.99.");
        if (quantity < 0) errors.add("Số lượng không được âm.");
        return errors;
    }
}
