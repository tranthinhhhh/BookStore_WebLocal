package vn.edu.hcmute.bookstore22110236.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class AppConfig_22110236 {
    private static final Properties PROPERTIES = new Properties();

    static {
        try (InputStream input = AppConfig_22110236.class.getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (input != null) {
                PROPERTIES.load(input);
            }
        } catch (IOException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private AppConfig_22110236() {
    }

    public static String get(String key) {
        String environmentValue = System.getenv(key);
        if (environmentValue != null && !environmentValue.isBlank()) {
            return environmentValue.trim();
        }
        return PROPERTIES.getProperty(key, "").trim();
    }

    public static boolean getBoolean(String key, boolean defaultValue) {
        String value = get(key);
        return value.isBlank() ? defaultValue : Boolean.parseBoolean(value);
    }

    public static int getInt(String key, int defaultValue) {
        try {
            return Integer.parseInt(get(key));
        } catch (NumberFormatException exception) {
            return defaultValue;
        }
    }
}
