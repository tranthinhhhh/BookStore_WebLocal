package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.config.AppConfig_22110236;
import vn.edu.hcmute.bookstore22110236.model.PendingRegistration_22110236;
import vn.edu.hcmute.bookstore22110236.service.IUserService_22110236;
import vn.edu.hcmute.bookstore22110236.service.MailService_22110236;
import vn.edu.hcmute.bookstore22110236.service.ServiceException_22110236;
import vn.edu.hcmute.bookstore22110236.service.UserService_22110236;
import vn.edu.hcmute.bookstore22110236.util.OtpUtil_22110236;
import vn.edu.hcmute.bookstore22110236.util.PasswordUtil_22110236;
import vn.edu.hcmute.bookstore22110236.util.ValidationUtil_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Locale;

@WebServlet("/register")
public class RegisterController_22110236 extends HttpServlet {
    private final IUserService_22110236 userService = new UserService_22110236();
    private final MailService_22110236 mailService = new MailService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = value(request, "email").toLowerCase(Locale.ROOT);
        String fullName = value(request, "fullName");
        String phone = value(request, "phone");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");
        List<String> errors = ValidationUtil_22110236.validateRegistration(
                email, fullName, phone, password, confirmPassword);
        if (errors.isEmpty() && userService.emailExists(email)) errors.add("Email đã được đăng ký.");
        if (!errors.isEmpty()) {
            request.setAttribute("errors", errors);
            request.setAttribute("email", email);
            request.setAttribute("fullName", fullName);
            request.setAttribute("phone", phone);
            doGet(request, response);
            return;
        }

        String otp = OtpUtil_22110236.generate();
        int expiryMinutes = AppConfig_22110236.getInt("OTP_EXPIRY_MINUTES", 5);
        PendingRegistration_22110236 pending = new PendingRegistration_22110236(
                email, fullName, phone, PasswordUtil_22110236.hash(password),
                OtpUtil_22110236.digest(otp), Instant.now().plus(expiryMinutes, ChronoUnit.MINUTES));
        try {
            mailService.sendOtp(email, otp);
            HttpSession session = request.getSession(true);
            session.setAttribute("pendingRegistration", pending);
            if (!mailService.isSmtpEnabled()) session.setAttribute("devOtp", otp);
            response.sendRedirect(request.getContextPath() + "/verify-otp");
        } catch (ServiceException_22110236 exception) {
            request.setAttribute("errors", List.of(exception.getMessage()));
            request.setAttribute("email", email);
            request.setAttribute("fullName", fullName);
            request.setAttribute("phone", phone);
            doGet(request, response);
        }
    }

    private String value(HttpServletRequest request, String name) {
        String value = request.getParameter(name);
        return value == null ? "" : value.trim();
    }
}
