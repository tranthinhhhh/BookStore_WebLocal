package vn.edu.hcmute.bookstore22110236.model;

import java.io.Serializable;
import java.time.Instant;

public class PendingRegistration_22110236 implements Serializable {
    private final String email;
    private final String fullName;
    private final String phone;
    private final String passwordHash;
    private final String otpDigest;
    private final Instant expiresAt;
    private int failedAttempts;

    public PendingRegistration_22110236(String email, String fullName, String phone,
                                        String passwordHash, String otpDigest, Instant expiresAt) {
        this.email = email;
        this.fullName = fullName;
        this.phone = phone;
        this.passwordHash = passwordHash;
        this.otpDigest = otpDigest;
        this.expiresAt = expiresAt;
    }

    public String getEmail() { return email; }
    public String getFullName() { return fullName; }
    public String getPhone() { return phone; }
    public String getPasswordHash() { return passwordHash; }
    public String getOtpDigest() { return otpDigest; }
    public Instant getExpiresAt() { return expiresAt; }
    public int getFailedAttempts() { return failedAttempts; }
    public void increaseFailedAttempts() { failedAttempts++; }
    public boolean isExpired() { return Instant.now().isAfter(expiresAt); }
}
