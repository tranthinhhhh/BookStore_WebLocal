<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html><head><title>Đăng ký</title></head><body>
<section class="form-card">
    <h1>Đăng ký tài khoản</h1>
    <p class="lead">Mã OTP gồm 6 số sẽ được gửi đến email để kích hoạt.</p>
    <c:if test="${not empty error}"><div class="alert error"><c:out value="${error}"/></div></c:if>
    <c:forEach var="message" items="${errors}"><div class="alert error"><c:out value="${message}"/></div></c:forEach>
    <form method="post" action="${pageContext.request.contextPath}/register">
        <div class="form-group"><label for="fullName">Họ và tên</label><input id="fullName" name="fullName" maxlength="100" value="<c:out value='${fullName}'/>" required></div>
        <div class="form-group"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="254" value="<c:out value='${email}'/>" required></div>
        <div class="form-group"><label for="phone">Số điện thoại</label><input id="phone" name="phone" maxlength="20" value="<c:out value='${phone}'/>" placeholder="0901234567"></div>
        <div class="form-group"><label for="password">Mật khẩu</label><input id="password" type="password" name="password" minlength="8" maxlength="72" required></div>
        <div class="form-group"><label for="confirmPassword">Xác nhận mật khẩu</label><input id="confirmPassword" type="password" name="confirmPassword" minlength="8" maxlength="72" required></div>
        <button class="button" type="submit">Gửi mã OTP</button>
    </form>
    <p class="auth-links">Đã có tài khoản? <a href="${pageContext.request.contextPath}/login">Đăng nhập</a></p>
</section>
</body></html>
