package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.Book_22110236;
import vn.edu.hcmute.bookstore22110236.service.BookService_22110236;
import vn.edu.hcmute.bookstore22110236.service.IBookService_22110236;
import vn.edu.hcmute.bookstore22110236.service.IRatingService_22110236;
import vn.edu.hcmute.bookstore22110236.service.RatingService_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

@WebServlet("/books/detail")
public class BookDetailController_22110236 extends HttpServlet {
    private final IBookService_22110236 bookService = new BookService_22110236();
    private final IRatingService_22110236 ratingService = new RatingService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int bookId = ControllerUtil_22110236.parseInt(request.getParameter("id"), 0);
        Optional<Book_22110236> book = bookService.getById(bookId);
        if (book.isEmpty()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        request.setAttribute("book", book.get());
        request.setAttribute("reviews", ratingService.getByBookId(bookId));
        request.getRequestDispatcher("/WEB-INF/views/book-detail.jsp").forward(request, response);
    }
}
