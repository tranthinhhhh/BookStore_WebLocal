package vn.edu.hcmute.bookstore22110236.repository;

public class RepositoryException_22110236 extends RuntimeException {
    public RepositoryException_22110236(String message, Throwable cause) {
        super(message, cause);
    }
}
