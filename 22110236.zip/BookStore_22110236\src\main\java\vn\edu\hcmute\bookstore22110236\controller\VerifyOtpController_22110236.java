package vn.edu.hcmute.bookstore22110236.controller;

import vn.edu.hcmute.bookstore22110236.model.PendingRegistration_22110236;
import vn.edu.hcmute.bookstore22110236.service.IUserService_22110236;
import vn.edu.hcmute.bookstore22110236.service.ServiceException_22110236;
import vn.edu.hcmute.bookstore22110236.service.UserService_22110236;
import vn.edu.hcmute.bookstore22110236.util.OtpUtil_22110236;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/verify-otp")
public class VerifyOtpController_22110236 extends HttpServlet {
    private final IUserService_22110236 userService = new UserService_22110236();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PendingRegistration_22110236 pending = getPending(request);
        if (pending == null) {
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }
        if (pending.isExpired()) {
            clearPending(request.getSession(false));
            request.setAttribute("error", "Mã OTP đã hết hạn. Vui lòng đăng ký lại.");
            request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
            return;
        }
        request.setAttribute("pendingEmail", pending.getEmail());
        request.setAttribute("devOtp", request.getSession().getAttribute("devOtp"));
        request.getRequestDispatcher("/WEB-INF/views/auth/verify-otp.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PendingRegistration_22110236 pending = getPending(request);
        if (pending == null) {
            response.sendRedirect(request.getContextPath() + "/register");
            return;
        }
        if (pending.isExpired()) {
            clearPending(request.getSession(false));
            request.setAttribute("error", "Mã OTP đã hết hạn. Vui lòng đăng ký lại.");
            request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
            return;
        }
        if (pending.getFailedAttempts() >= 5) {
            clearPending(request.getSession(false));
            request.setAttribute("error", "Bạn đã nhập sai quá 5 lần. Vui lòng đăng ký lại.");
            request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
            return;
        }
        if (!OtpUtil_22110236.matches(request.getParameter("otp"), pending.getOtpDigest())) {
            pending.increaseFailedAttempts();
            request.setAttribute("error", "Mã OTP không đúng. Còn " + (5 - pending.getFailedAttempts()) + " lần thử.");
            doGet(request, response);
            return;
        }
        try {
            userService.activate(pending);
            clearPending(request.getSession(false));
            response.sendRedirect(request.getContextPath() + "/login?registered=success");
        } catch (ServiceException_22110236 exception) {
            clearPending(request.getSession(false));
            request.setAttribute("error", exception.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/auth/register.jsp").forward(request, response);
        }
    }

    private PendingRegistration_22110236 getPending(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        return session == null ? null
                : (PendingRegistration_22110236) session.getAttribute("pendingRegistration");
    }

    private void clearPending(HttpSession session) {
        if (session != null) {
            session.removeAttribute("pendingRegistration");
            session.removeAttribute("devOtp");
        }
    }
}
