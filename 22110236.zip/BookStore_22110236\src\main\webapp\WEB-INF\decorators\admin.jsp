<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><sitemesh:write property="title"/> - Quản trị</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/css/app.css">
    <sitemesh:write property="head"/>
</head>
<body class="admin-body">
<header class="site-header admin-header">
    <div class="container nav-wrap">
        <a class="brand" href="${pageContext.request.contextPath}/admin/books">Quản trị BookStore</a>
        <nav class="main-nav">
            <a href="${pageContext.request.contextPath}/home">Trang chủ</a>
            <a href="${pageContext.request.contextPath}/products">Sản phẩm</a>
            <a class="admin-link" href="${pageContext.request.contextPath}/admin/books">Trang quản trị</a>
            <form class="nav-form" method="post" action="${pageContext.request.contextPath}/logout">
                <button class="link-button" type="submit">Đăng xuất</button>
            </form>
        </nav>
    </div>
</header>
<main class="container main-content">
    <sitemesh:write property="body"/>
</main>
<footer class="site-footer">
    <div class="container">Trần Tiến Thịnh – 22110236 – Đề 02</div>
</footer>
</body>
</html>
