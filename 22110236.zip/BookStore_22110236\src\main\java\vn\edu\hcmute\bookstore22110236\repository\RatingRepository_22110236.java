package vn.edu.hcmute.bookstore22110236.repository;

import vn.edu.hcmute.bookstore22110236.config.DatabaseConnection_22110236;
import vn.edu.hcmute.bookstore22110236.model.Rating_22110236;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RatingRepository_22110236 implements IRatingRepository_22110236 {
    @Override
    public List<Rating_22110236> findByBookId(int bookId) {
        String sql = "SELECT r.userid, r.bookid, r.rating, r.review_text, u.fullname "
                + "FROM rating r JOIN users u ON u.id = r.userid WHERE r.bookid = ? ORDER BY u.fullname";
        List<Rating_22110236> ratings = new ArrayList<>();
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, bookId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    Rating_22110236 rating = new Rating_22110236();
                    rating.setUserId(resultSet.getInt("userid"));
                    rating.setBookId(resultSet.getInt("bookid"));
                    rating.setRating(resultSet.getInt("rating"));
                    rating.setReviewText(resultSet.getString("review_text"));
                    rating.setUserName(resultSet.getString("fullname"));
                    ratings.add(rating);
                }
            }
            return ratings;
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể tải đánh giá.", exception);
        }
    }

    @Override
    public void saveOrUpdate(Rating_22110236 rating) {
        String sql = "UPDATE rating SET rating = ?, review_text = ? WHERE userid = ? AND bookid = ?; "
                + "IF @@ROWCOUNT = 0 INSERT INTO rating(userid, bookid, rating, review_text) VALUES (?, ?, ?, ?);";
        try (Connection connection = DatabaseConnection_22110236.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, rating.getRating());
            statement.setString(2, rating.getReviewText());
            statement.setInt(3, rating.getUserId());
            statement.setInt(4, rating.getBookId());
            statement.setInt(5, rating.getUserId());
            statement.setInt(6, rating.getBookId());
            statement.setInt(7, rating.getRating());
            statement.setString(8, rating.getReviewText());
            statement.executeUpdate();
        } catch (SQLException exception) {
            throw new RepositoryException_22110236("Không thể lưu đánh giá.", exception);
        }
    }
}
