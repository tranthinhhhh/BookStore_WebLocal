package vn.edu.hcmute.bookstore22110236.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class DatabaseConnection_22110236 {
    static {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException exception) {
            throw new ExceptionInInitializerError(exception);
        }
    }

    private DatabaseConnection_22110236() {
    }

    public static Connection getConnection() throws SQLException {
        String url = AppConfig_22110236.get("DB_URL");
        String user = AppConfig_22110236.get("DB_USER");
        String password = AppConfig_22110236.get("DB_PASSWORD");
        if (url.isBlank() || user.isBlank() || password.isBlank()) {
            throw new SQLException("Chưa cấu hình đầy đủ DB_URL, DB_USER và DB_PASSWORD.");
        }
        return DriverManager.getConnection(url, user, password);
    }
}
